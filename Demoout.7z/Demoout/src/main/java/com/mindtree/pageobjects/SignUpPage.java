package com.mindtree.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;

import com.mindtree.reusuablecomponents.AllObjects;
import com.mindtree.uistore.SignUpPageUi;

/*
 * Implementing all SignUpPage actionkeywords in SignUpPage class
 */

public class SignUpPage extends AllObjects {

	public static WebDriver driver;

	// Creating Object and calling through page object model
	SignUpPageUi signUpPageObject = PageFactory.initElements(driver, SignUpPageUi.class);
	
	
	public void openBrowser() throws FileNotFoundException, IOException, InterruptedException {
		driver = commonlibraries.setUp();

	}

	public void navigate() throws FileNotFoundException, IOException {
		driver.get(propertyFiledata.takeDataFromProperty().getProperty("url"));
	}

	public void register() {
		commonlibraries.click(signUpPageObject.register);
	}

	public void username() throws Exception {
		String excelsheetpath = System.getProperty("user.dir")
				+ propertyFiledata.takeDataFromProperty().getProperty("excelPath");
		exceldata.setExcelFile(excelsheetpath, "signup");
		commonlibraries.sendkeys(signUpPageObject.username, exceldata.getCellData(4, 4));
	}

	public void password() throws Exception {
		String excelsheetpath = System.getProperty("user.dir")
				+ propertyFiledata.takeDataFromProperty().getProperty("excelPath");
		exceldata.setExcelFile(excelsheetpath, "signup");
		commonlibraries.sendkeys(signUpPageObject.password, exceldata.getCellData(5, 4));
	}

	public void email() throws Exception {
		String excelsheetpath = System.getProperty("user.dir")
				+ propertyFiledata.takeDataFromProperty().getProperty("excelPath");
		exceldata.setExcelFile(excelsheetpath, "signup");
		commonlibraries.sendkeys(signUpPageObject.email, exceldata.getCellData(6, 4));
	}

	public void fullName() throws Exception {
		String excelsheetpath = System.getProperty("user.dir")
				+ propertyFiledata.takeDataFromProperty().getProperty("excelPath");
		exceldata.setExcelFile(excelsheetpath, "signup");
		commonlibraries.sendkeys(signUpPageObject.fullName, exceldata.getCellData(7, 4));
	}

	public void submit() throws InterruptedException {
		commonlibraries.click(signUpPageObject.submit);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	public void closeBrowser() {
		commonlibraries.tearDown(driver);
	}

	static String winHandleBefore = "";

	public void loginwithGoogle() {
		commonlibraries.webdriverWait(signUpPageObject.googleLogin, driver, 20);
		commonlibraries.click(signUpPageObject.googleLogin);
		winHandleBefore = driver.getWindowHandle();
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
	}

	public void googleEmail() throws Exception {

		commonlibraries.webdriverWait(signUpPageObject.googleEmailId, driver, 20);
		commonlibraries.sendkeys(signUpPageObject.googleEmailId, "medha.gudihal@gmail.com");
	}

	public void emailNextButton() {
		commonlibraries.webdriverWait(signUpPageObject.googleNextButton, driver, 20);
		commonlibraries.click(signUpPageObject.googleNextButton);
	}

	public void googlePassword() throws Exception {
		commonlibraries.webdriverWait(signUpPageObject.googlePassword, driver, 20);
		commonlibraries.sendkeys(signUpPageObject.googlePassword, "hey@12345");
	}

	public void passwordNextButton() {
		commonlibraries.webdriverWait(signUpPageObject.googlePasswordNextButton, driver, 20);
		commonlibraries.click(signUpPageObject.googlePasswordNextButton);
		driver.switchTo().window(winHandleBefore);
		driver.navigate().refresh();
	}

}
