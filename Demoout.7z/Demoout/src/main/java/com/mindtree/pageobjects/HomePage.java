 package com.mindtree.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;

import com.mindtree.reusuablecomponents.AllObjects;
import com.mindtree.uistore.HomePageUi;

/*
 * Implementing all homepage actionkeywords in homepage class
 */
public class HomePage extends AllObjects {

	public static WebDriver driver;

	// Creating Object and calling through page object model
	HomePageUi homepageObject = PageFactory.initElements(driver, HomePageUi.class);
	
	public void openBrowser() throws FileNotFoundException, IOException, InterruptedException {
		driver = commonlibraries.setUp();

	}

	public void navigate() throws FileNotFoundException, IOException {
		driver.get(propertyFiledata.takeDataFromProperty().getProperty("url"));
		System.out.println("hell");
	}

	public void homeButton() {
		commonlibraries.click(homepageObject.home);
	}

	public void newCars() throws InterruptedException {
		commonlibraries.mouseHover(driver, homepageObject.newCars);
		//Thread.sleep(6000);
	}

	public void seeAllNewCars() throws InterruptedException {
		commonlibraries.click(homepageObject.seeAllNewCars);
		//Thread.sleep(5000);
		driver.navigate().back();
	}

	public void searchNewCars() throws InterruptedException {
		commonlibraries.click(homepageObject.searchNewCars);
		//Thread.sleep(3000);
		driver.navigate().refresh();
	}

	public void usedCars() throws InterruptedException {
		//Thread.sleep(2000);
		commonlibraries.mouseHover(driver, homepageObject.usedCars);

	}

	public void seeAllUsedCars() throws InterruptedException {
		//Thread.sleep(5000);
		commonlibraries.click(homepageObject.seeAllUsedCars);
		driver.navigate().back();
	}

	public void searchUsedCars() throws InterruptedException {
		commonlibraries.click(homepageObject.searchUsedCars);
		//Thread.sleep(3000);
		driver.navigate().refresh();
	}

	public void brands() throws InterruptedException {
		//Thread.sleep(2000);
		commonlibraries.mouseHover(driver, homepageObject.brands);

	}

	public void ford() throws InterruptedException {
		//Thread.sleep(2000);
		commonlibraries.click(homepageObject.ford);
	}

	public void toyota() throws InterruptedException {
		//Thread.sleep(2000);
		// commonlibraries.mouseHover(driver, homepageObject.brands);
		commonlibraries.click(homepageObject.toyota);
	}

	public void renault() throws InterruptedException {
		//Thread.sleep(2000);
		commonlibraries.click(homepageObject.renault);
	}

	public void closeBrowser() {
		commonlibraries.tearDown(driver);
	}

}
