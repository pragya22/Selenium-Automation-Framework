package com.mindtree.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.reusuablecomponents.AllObjects;
import com.mindtree.uistore.AdminUi;
import com.mindtree.uistore.PatnerPageUi;

public class PatnerPage extends AllObjects {
	public static WebDriver driver;

	public String dataPassToWebelement;

	public WebElement webelementPath;

	static String winHandleBefore = "";

	// Creating Object and calling through page object model
	PatnerPageUi patnerPageObject = PageFactory.initElements(driver, PatnerPageUi.class);

	public void openBrowser() throws FileNotFoundException, IOException, InterruptedException {
		driver = commonlibraries.setUp();

	}

	public void navigate() throws FileNotFoundException, IOException {
		driver.get(propertyFiledata.takeDataFromProperty().getProperty("url"));
	}

	public void login() {
		commonlibraries.click(patnerPageObject.login);
		
		
	}

	public void username() throws Exception {
		commonlibraries.sendkeys(patnerPageObject.userName,"PartnerDeepika");
	}

	public void password() throws Exception {

		commonlibraries.sendkeys(patnerPageObject.password,"9876543210");
	}

	public void submiit() throws InterruptedException {
		commonlibraries.webdriverWait(patnerPageObject.submit, driver, 5);
		//Thread.sleep(5000);
		commonlibraries.click(patnerPageObject.submit);
		//commonlibraries.webdriverWait(loginPageObject.logout, driver, 5);
	}
	
	public void clickOnPartner()
	{
		commonlibraries.webdriverWait(patnerPageObject.patner, driver, 5);
		commonlibraries.click(patnerPageObject.patner);
	}
	
	public void closeBrowser() {
		commonlibraries.tearDown(driver);
	}

}
