package com.mindtree.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import com.mindtree.reusuablecomponents.AllObjects;
import com.mindtree.uistore.SearchFlightUi;
import com.mindtree.utility.Scroll;

public class SearchFlightPage extends AllObjects{


	public String dataPassToWebelement;

	public WebElement webelementPath;

	static String winHandleBefore = "";

	// Creating Object and calling through page object model
	SearchFlightUi searchFlightObject = PageFactory.initElements(driver, SearchFlightUi.class);


	public void submitFlight() throws InterruptedException {
		
		//commonlibraries.scrollDown();
		Scroll scroll = new Scroll();
		scroll.scrollDown();
		Thread.sleep(7000);
		commonlibraries.click(searchFlightObject.book);
		

	}
	public void closeBrowser() {
		commonlibraries.tearDown(driver);
	}
	
}
