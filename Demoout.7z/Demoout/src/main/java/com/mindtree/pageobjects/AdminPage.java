package com.mindtree.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mindtree.reusuablecomponents.AllObjects;
import com.mindtree.uistore.AdminUi;
import com.mindtree.uistore.LoginPageUi;

public class AdminPage extends AllObjects{
	public static WebDriver driver;

	public String dataPassToWebelement;

	public WebElement webelementPath;

	static String winHandleBefore = "";

	// Creating Object and calling through page object model
	AdminUi adminPageObject = PageFactory.initElements(driver, AdminUi.class);

	public void openBrowser() throws FileNotFoundException, IOException, InterruptedException {
		driver = commonlibraries.setUp();

	}

	public void navigate() throws FileNotFoundException, IOException {
		driver.get(propertyFiledata.takeDataFromProperty().getProperty("url"));
	}

	public void login() {
		commonlibraries.click(adminPageObject.login);
		
		
	}

	public void username() throws Exception {
		commonlibraries.sendkeys(adminPageObject.userName,"Superuser");
	}

	public void password() throws Exception {

		commonlibraries.sendkeys(adminPageObject.password,"Mindtree@12");
	}

	public void submiit() throws InterruptedException {
		commonlibraries.webdriverWait(adminPageObject.submit, driver, 5);
		//Thread.sleep(5000);
		commonlibraries.click(adminPageObject.submit);
		//commonlibraries.webdriverWait(loginPageObject.logout, driver, 5);
	}
	
	public void clickOnAdmin()
	{
		commonlibraries.webdriverWait(adminPageObject.admin, driver, 5);
		commonlibraries.click(adminPageObject.admin);
	}
	
	public void allcarList() throws InterruptedException
	{
		commonlibraries.webdriverWait(adminPageObject.allCarsList, driver, 5);
		
		commonlibraries.click(adminPageObject.allCarsList);
	}
	
	public void deleteCar()
	{
		
		commonlibraries.webdriverWait(adminPageObject.deleteCar, driver, 5);
		
		commonlibraries.click(adminPageObject.deleteCar);
	}
	
	public void addPartner()
	{
		commonlibraries.click(adminPageObject.addAPartner);
	}
	
	public void details()
	{
		commonlibraries.sendkeys(adminPageObject.name, "Janhavi");
		commonlibraries.sendkeys(adminPageObject.contact, "7026944491");
		commonlibraries.sendkeys(adminPageObject.address, "yet to know");
		commonlibraries.sendkeys(adminPageObject.city, "Belgaum");
		commonlibraries.sendkeys(adminPageObject.state,"Karnataka");
		
	}
	
	public void clickAddprovider()
	{
		commonlibraries.click(adminPageObject.addProviderButton);
	}
	
	public void providers()
	{
		commonlibraries.click(adminPageObject.providers);
	}
	
	public void clickOnJanvi()
	{
		commonlibraries.click(adminPageObject.clickOnProvider);
		
	}
	
	public void updateDetail()
	{
		adminPageObject.name.clear();
		commonlibraries.sendkeys(adminPageObject.name, "Ruturaj");
		
		
		adminPageObject.contact.clear();
		commonlibraries.sendkeys(adminPageObject.contact, "1234567890");
		
	}
	public void clickOnUpdateProvider()
	{
		commonlibraries.click(adminPageObject.updateProvider);
	}
	
	public void addCar()
	{
		commonlibraries.click(adminPageObject.addCar);
	}
	
	public void addCarDetails()
	{
		commonlibraries.click(adminPageObject.usedCarSelect);
		commonlibraries.sendkeys(adminPageObject.model, "suzuki");
		
		Select select = new Select(adminPageObject.brand);
        select.selectByVisibleText("Tata"); 
        
       //Select select1 = new Select(adminPageObject.stock);
        commonlibraries.sendkeys(adminPageObject.stock,"2");
        
        Select select2 = new Select(adminPageObject.body);
        select2.selectByVisibleText("Sedan"); 
        
        Select select3 = new Select(adminPageObject.fuel);
        select3.selectByVisibleText("Petrol"); 
        
        Select select4 = new Select(adminPageObject.transmission);
        select4.selectByVisibleText("Manual"); 
        
        Select select5 = new Select(adminPageObject.provider);
        select5.selectByVisibleText("Janhavi"); 
        
        //Select select6 = new Select(adminPageObject.mileage);
        commonlibraries.sendkeys(adminPageObject.mileage,"10");
        
       // Select select7 = new Select(adminPageObject.engineCC);
        commonlibraries.sendkeys(adminPageObject.engineCC,"200");
        
        //Select select8 = new Select(adminPageObject.price);
        commonlibraries.sendkeys(adminPageObject.price,"200000");
        commonlibraries.click(adminPageObject.addNewCarButton);
        
        
	}
	
	public void closeBrowser() {
		commonlibraries.tearDown(driver);
	}
	
}
