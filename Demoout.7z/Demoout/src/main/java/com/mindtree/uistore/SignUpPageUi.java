package com.mindtree.uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/*
 * SignUpPageUi is a class which contains all locators or webelements of SignUpPage 
 *  of MyCar project 
 * 
 */

public class SignUpPageUi {

	@FindBy(linkText = "Register")
	public WebElement register;

	@FindBy(xpath = "//input[@pattern='\\w{5,255}']")
	public WebElement username;

	@FindBy(xpath = "//input[@pattern='^(?=[^\\d_].*?\\d)\\w(\\w|[!@#$%]){8,50}']")
	public WebElement password;

	@FindBy(name = "Email")
	public WebElement email;

	@FindBy(name = "Name")
	public WebElement fullName;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	public WebElement submit;

	@FindBy(linkText = "verify")
	public WebElement verify;

	@FindBy(xpath = "//input[@formcontrolname='email']")
	public WebElement enterEmail;

	@FindBy(xpath = "button[contains(text(),'Send OTP')]")
	public WebElement sendOtp;

	/*
	 * @FindBy(linkText = "Verify") public WebElement verifyOtp;
	 */

	@FindBy(xpath = "//input[@placeholder='Enter your OTP number']")
	public WebElement enterOtp;

	@FindBy(xpath = "button[contains(text(),'Verify OTP')]")
	public WebElement verifyOtp;

	@FindBy(xpath = "//*[@id=\"signupModal\"]/div/div/div[2]/app-sign-up/div/div/div/button[2]")
	public WebElement googleLogin;

	@FindBy(xpath = "//input[@id='identifierId']")
	public WebElement googleEmailId;

	@FindBy(xpath = "//span[contains(text(),'Next')]")
	public WebElement googleNextButton;

	@FindBy(xpath = "//input[@name='password']")
	public WebElement googlePassword;

	@FindBy(xpath = "//span[contains(text(),'Next')]")
	public WebElement googlePasswordNextButton;

}
