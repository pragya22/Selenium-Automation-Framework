
package com.mindtree.uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;


public class FlightFinderUi {

    
    /*
    * SearchNewCarUi is a class which contains all locators or web elements of Search new car page
    * 
     * 
     */
              @FindBy(xpath = "//select[@name='passCount']")
              public WebElement noOfPassengers;

    @FindBy(name = "fromPort")
    public WebElement departingFrom;

    @FindBy(name = "toPort")
    public WebElement toPort;

    @FindBy(name = "toMonth")
    @CacheLookup
    public WebElement toMonth;

    @FindBy(name = "toDay")
    public WebElement toDay;

    @FindBy(name = "servClass")
    public WebElement serviceClass;

    @FindBy(name = "airline")
    public WebElement airline;

                   

}



