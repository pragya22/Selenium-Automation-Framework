package com.mindtree.uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatnerPageUi {

	@FindBy(xpath = "//a[contains(text(),'Login')]")
	public WebElement login;

	@FindBy(xpath = "//input[@name='UserName']")
	public WebElement userName;

	@FindBy(xpath = "//input[@name='Password']")
	public WebElement password;

	@FindBy(xpath = "//button[@type='submit' and contains(text(),'Login')]")
	public WebElement submit;

	@FindBy(xpath = "//a[contains(text(),'Home')]")
	public WebElement home;

	@FindBy(xpath = "/html/body/meta�http-equiv=\"x-ua-compatible\"/app-root/app-guest-template/html/body/app-footer/footer/div[1]/div/div[2]/div/div/div[1]/div[2]/div/span/a[2]")
	public WebElement patner;
}
