package com.mindtree.uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/*
 * HomePageUi is a class which contains all locators or webelements of HomePage or
 * LandingPage of MyCar project 
 * 
 */

public class HomePageUi {

	@FindBy(xpath = "//span[contains(text(),'Cars')]")
	public WebElement myCars;

	@FindBy(xpath = "//a[contains(text(),'Home')]")
	public WebElement home;

	@FindBy(xpath = "//a[@id='navbardrop']")
	public WebElement newCars;

	@FindBy(xpath = "//a[contains(text(),'See all new cars')]")
	public WebElement seeAllNewCars;

	@FindBy(xpath = "//a[contains(text(),'Search new cars')]")
	public WebElement searchNewCars;

	@FindBy(xpath = "//a[contains(text(),'Used Cars')]")
	public WebElement usedCars;

	@FindBy(xpath = "//a[contains(text(),'See all used cars')]")
	public WebElement seeAllUsedCars;

	@FindBy(xpath = "//a[contains(text(),'Search used cars')]")
	public WebElement searchUsedCars;

	@FindBy(xpath = "//a[contains(text(),'Brands')]")
	public WebElement brands;

	@FindBy(xpath = "//a[contains(text(),'Ford')]")
	public WebElement ford;

	@FindBy(xpath = "//a[contains(text(),'Toyota')]")
	public WebElement toyota;

	@FindBy(xpath = "//a[contains(text(),'Renault')]")
	public WebElement renault;

	@FindBy(xpath = "//a[contains(text(),'Login')]")
	public WebElement login;

	@FindBy(xpath = "//a[contains(text(),'Register')]")
	public WebElement register;

}
