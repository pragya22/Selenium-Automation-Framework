package com.mindtree.uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminUi {
	
	@FindBy(xpath = "//a[contains(text(),'Login')]")
	public WebElement login;

	@FindBy(xpath = "//input[@name='UserName']")
	public WebElement userName;

	@FindBy(xpath = "//input[@name='Password']")
	public WebElement password;

	@FindBy(xpath = "//button[@type='submit' and contains(text(),'Login')]")
	public WebElement submit;

    @FindBy(xpath = "//a[contains(text(),'Home')]")
    public WebElement home;

    @FindBy(xpath = "//a[contains(text(),'Admin')]")
    public WebElement admin;

    @FindBy(xpath = "//p[contains(text(),'All Cars List')]")
    public WebElement allCarsList;

    @FindBy(xpath = "//button[contains(text(),'Delete')]")
    public WebElement deleteCar;
    
    @FindBy(xpath = "//p[contains(text(),'Add a Partner')]")
    public WebElement addAPartner;

    @FindBy(xpath = "//input[@name='Name']")
    public WebElement name;

    @FindBy(xpath = "//input[@name='Contact']")
    public WebElement contact;

    @FindBy(xpath = "//input[@name='Address']")
    public WebElement address;

    @FindBy(xpath = "//input[@name='City']")
    public WebElement city;

    @FindBy(xpath = "//input[@name='State']")
    public WebElement state;

    @FindBy(xpath = "//button[contains(text(),'Add Provider')]")
    public WebElement addProviderButton;

    
    @FindBy(xpath = "//p[contains(text(),'Add Car')]")
    public WebElement addCar;

    @FindBy(xpath ="//h4[contains(text(),'Used Car')]")
    public WebElement usedCarSelect;
    
    @FindBy(xpath="//input[@name='Model']")
    public WebElement model;
    
    @FindBy(xpath="//select[@name='Brand']")
    public WebElement brand;
    
    @FindBy(xpath="//input[@name='Stock']")
    public WebElement stock;

    @FindBy(xpath="//select[@name='Body']")
    public WebElement body;
    
    @FindBy(xpath="//select[@name='Fuel']")
    public WebElement fuel;
    
    @FindBy(xpath="//select[@name='Transmission']")
    public WebElement transmission;
    
    @FindBy(xpath="//select[@name='Provider']")
    public WebElement provider;
    
    @FindBy(xpath="//input[@name='DistanceTravelled']")
    public WebElement distanceTravelled;
    
    @FindBy(xpath="//input[@name='RegistrationDate']")
    public WebElement registrationDate;
    
    @FindBy(name = "Mileage")
    public WebElement mileage;
    
    @FindBy(name = "EngineCC")
    public WebElement engineCC;
    
    @FindBy(name = "Price")
    public WebElement price;
    
    @FindBy(xpath="//button[contains(text(),'Add Used Car')]")
    public WebElement addUsedCarButton;
    
    @FindBy(xpath="//button[contains(text(),'New Car')]")
    public WebElement newCarSelect;
    
    @FindBy(xpath="//input[contains(text(),'Model')]")
    public WebElement modelNew;
    
    @FindBy(xpath="//input[@name='Brand']")
    public WebElement brandNew;
    
    @FindBy(xpath="//input[@name='Stock']")
    public WebElement stockNew;

    @FindBy(xpath="//input[@name='Body']")
    public WebElement bodyNew;
    
    @FindBy(xpath="//input[@name='Fuel']")
    public WebElement fuelNew;
    
    @FindBy(xpath="//input[@name='Transmission']")
    public WebElement transmissionNew;
    
    @FindBy(xpath="//input[@name='Provider']")
    public WebElement providerNew;
    
    @FindBy(xpath="//input[@name='Mileage']")
    public WebElement mileageNew;
    
    @FindBy(xpath="//input[@name='EngineCC']")
    public WebElement engineCCNew;
    
    @FindBy(xpath="//input[@name='Price']")
    public WebElement priceNew;
    
    @FindBy(xpath="//button[@type='submit']")
    public WebElement addNewCarButton;
    
    @FindBy(xpath="//p[contains(text(),'Providers')]")
    public WebElement providers;
    
    @FindBy(xpath="//button[contains(text(),'Delete')]")
    public WebElement deleteProviderButton;

    @FindBy(xpath = "//div[@class='content table-responsive table-full-width']//td[contains(text(), 'Janhavi')]")
    public WebElement clickOnProvider;
    
    @FindBy(xpath = "//button[@type='submit']")
    public WebElement updateProvider;

}
