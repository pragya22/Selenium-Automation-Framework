package com.mindtree.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;
import com.mindtree.reusuablecomponents.Report;

public class HtmlToPDF {
	public static void generatePDF(String inputHtmlPath, String outputPdfPath)
	{
	    try {
	        String url = new File(inputHtmlPath).toURI().toURL().toString();
	        System.out.println("URL: " + url);

	        OutputStream out = new FileOutputStream(outputPdfPath);

	        //Flying Saucer part
	        ITextRenderer renderer = new ITextRenderer();

	        renderer.setDocument(url);
	        renderer.layout();
	        renderer.createPDF(out);

	        out.close();
	    } catch (DocumentException | IOException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
	}
    public static void pdfConverter(){
        String inputFile = System.getProperty("user.dir") + "/report/extentreport/"+Report.da+"/MercuryTravels.html";
        String outputFile = System.getProperty("user.dir") + "/report/extentreport/"+Report.da+"/MercuryTravels.pdf";

        generatePDF(inputFile, outputFile);

        System.out.println("Done!");
    }

}
