package com.mindtree.executionengine;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mindtree.pageobjectactionkeywords.SearchFlightPageKeywords;
import com.itextpdf.text.DocumentException;
import com.mindtree.pageobjectactionkeywords.BookFlightPageKeywords;
import com.mindtree.pageobjectactionkeywords.FlightFinderKeywords;
import com.mindtree.pageobjectactionkeywords.LoginPageKeywords;
import com.mindtree.reusuablecomponents.AllObjects;
import com.mindtree.reusuablecomponents.CommonComponents;
import com.mindtree.reusuablecomponents.Report;
import com.mindtree.utility.HtmlToPDF2;
import com.mindtree.utility.PropertyFileData;
import com.mindtree.utility.SendAttachmentInEmail;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

/*
 * MyCarTest is main class contains all test cases related to mycar project Test
 * cases will start executing from here
 * 
 */
public class MainProgram extends AllObjects{

	PropertyFileData propertyFiledata = new PropertyFileData();
	CommonComponents components = new CommonComponents();

	public static ExtentReports extentreport;
	Report report = new Report();
	String run;
	static int i=0;

	@BeforeTest
	public void startExtentReport() throws FileNotFoundException, IOException, InterruptedException {
		run = propertyFiledata.takeDataFromProperty().getProperty("Flow");
		extentreport = report.generateReport();

	}


	/*
	 * login is a test which is checking weather end user will be able to login,
	 * into demoout through normal login credentials
	 */

//	@Test(priority = 1, dataProvider = "Authentication")
//	public void roundtrip(String username, String password) throws Exception {
//
//		/* loginPage is a object of LoginPageKeywords class * fetchKeywords is a method
//		 * which is present in LoginPageKeywords class and this method fetching keywords
//		 * from excel sheet*/
//		test=extentreport.startTest("roundtrip Testcase");
//		LoginPageKeywords loginPage = new LoginPageKeywords();
//		loginPage.fetchKeywords(username, password);
//		FlightFinderKeywords flightfinder = new FlightFinderKeywords();
//		flightfinder.fetchKeywords();
//		SearchFlightPageKeywords searchFlight = new SearchFlightPageKeywords();
//		searchFlight.fetchKeywords();
//		BookFlightPageKeywords bookFlight= new BookFlightPageKeywords();
//		bookFlight.fetchKeywords();
//
//		report.writeToReport();
//	}

	@Test(priority = 2, dataProvider = "Credentials")
	public void validate(String username, String password) throws Exception {
		/*
		 * loginValidatePage is a object of LoginValidateKeywords class * vfetchKeywords is a method
		 * which is present in LoginPageKeywords class and this method fetching keywords
		 * from excel sheet
		 */
		test=extentreport.startTest("Validate Testcase");
		//Validation
		LoginPageKeywords loginValidatePage = new LoginPageKeywords();
		loginValidatePage.vfetchKeywords(username, password);
		report.writeToReport();
	}



	@DataProvider
	public Object[][] Authentication() throws Exception {

		return components.dataprovider("logincredentials");
	}

	@DataProvider
	public Object[][] Credentials() throws Exception {

		return components.dataprovider("validateCredentials");
	}
	@AfterMethod
	public void teardown()
	{driver.close();}
/*
	@AfterTest()
	public void sendmail() throws IOException, DocumentException {
	
		//SendAttachmentInEmail.mail();
	    

	}*/
	@AfterClass()
	public void pdf() throws IOException, DocumentException
	{
		 File file = new File(DEST);
	        file.getParentFile().mkdirs();
	        new HtmlToPDF2().createPdf(DEST);

		
	}
}




